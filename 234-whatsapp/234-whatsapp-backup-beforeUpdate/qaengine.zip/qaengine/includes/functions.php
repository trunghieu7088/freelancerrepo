<?php
/**
 * allow this post url format: http://localhost/et/qae/question/test/page/2
 * @since 2.0.18
*/
function qae_custom_disable_redirect_canonical( $redirect_url ){
    global $post;
    $ptype = get_post_type( $post );
    $paged = get_query_var( 'paged' ) ? get_query_var( 'paged' ) : 1 ;

    if ( $ptype == 'question' && $paged >1 ) $redirect_url = false;
    return $redirect_url;
}
add_filter( 'redirect_canonical','qae_custom_disable_redirect_canonical',1 );

/**
 * This is a new define for pagination
 **/
function qae_paginate_link($query, $echo = true){
    $big = 999999999999;
    $current = get_query_var('paged');
    if( is_home() || is_front_page() ){
        $current = get_query_var('page');
    }

    $html = paginate_links( array(
        'base' => str_replace( $big, '%#%', esc_url( get_pagenum_link( $big ) ) ),
        'format' => '?paged=%#%',
        'current' => max( 1, $current ),
        'total' => $query->max_num_pages,
        'prev_text' => '<',
        'next_text' => '>',
        'type'      => 'list'
    ));
    if(!$echo)
        return $html;
    echo  $html;
}