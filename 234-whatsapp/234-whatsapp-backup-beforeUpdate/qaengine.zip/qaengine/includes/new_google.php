<?php
// clienID: 375492077091-4ureejkh29etvm5to0mv1edu8mgc7h0b.apps.googleusercontent.com
//seceret key:gWt6RViHphfOIQT84_4B6ZIJ
// php api https://github.com/googleapis/google-api-php-client
// endpoit verify token: https://developers.google.com/identity/sign-in/web/backend-auth#calling-the-tokeninfo-endpoint

//https://developers.google.com/identity/sign-in/web/backend-auth#calling-the-tokeninfo-endpoint
define('GOOGLE_CLIENT_ID','375492077091-4ureejkh29etvm5to0mv1edu8mgc7h0b.apps.googleusercontent.com');
define('GOOGLE_SECRET_KEY','gWt6RViHphfOIQT84_4B6ZIJ');
class Google_Login{
	public $enable;
	public $client_id;
	public $secret_key;
	function __construct(){
		$this->enable = ae_get_option('gplus_login', false);
		$this->client_id = ae_get_option('gplus_client_id');
		$this->secret_key = ae_get_option('gplus_secret_id');

		add_action('wp_head', array($this, 'add_wp_head_script'));
		add_action('before_social_login_btn',array($this, 'add_btn_login') );
		add_action('wp_ajax_nopriv_verify_reponse', array($this,'verify_reponse'));

	}
	function is_enabling(){
		if(!$this->enable)
			return 0;
		if( empty($this->client_id) || empty($this->secret_key) )
			return 0;
		return 1;
	}
	function verify_reponse(){
		$id_token = $_REQUEST['id_token'];
		//https://oauth2.googleapis.com/tokeninfo?id_token=XYZ123

		$uri ="https://oauth2.googleapis.com/tokeninfo";
		$headers = array(
			'Host'=> 'oauth2.googleapis.com',
			'Content-Type' =>'application/x-www-form-urlencoded',
		);
		$args = array(
			'method' => 'GET',
			'body' => array(
			    'id_token' => $id_token
			),
			'headers' => $headers,
			'httpversion' => '1.1',
			'timeout'     => 120,
		);


		$remote_get = wp_remote_get( $uri, $args );
		$data = json_decode( $remote_get ['body'] );
		$google_user_id = $data->sub;

		$user_id = 0;
		$user 	= get_user_by( 'email', $data->email );

		if($user){
			// log in here;
			$user_id = $user->ID;
			wp_set_current_user( $user->ID, $user->user_login);
		    wp_set_auth_cookie( $user->ID );
		} else {
			// redirect to next page to confirm;
			//header("Location: http://localhost:8080/meet2eat/index.php");

			$userdata = array(
			    'user_login' =>  $data->sub,
			    'user_email' =>  $data->email,
			    'user_nicename' =>  $data->name,
			    'display_name'=> $data->name,
			   // 'user_url'   =>  $website,
			    'user_pass'  =>  wp_generate_password(), // When creating an user, `user_pass` is expected.
			);

			$user_id = wp_insert_user( $userdata ) ;

			wp_set_current_user( $user_id, $data->sub );
		    wp_set_auth_cookie( $user_id );
		}
		$resp = array(
			'success' => true,
			'msg' =>'OK',
			'redirect_uri' => get_author_posts_url($user_id),
		);
		wp_send_json($resp);

	}

	function add_btn_login( $new_btn ){

		$btn_id = "signInGoogleBtn";
		if( $new_btn){
			$btn_id = "newSignInGoogleBtn";
		}

		if( $this->is_enabling() ){ ?>
			<li class="ngp">
				<span id="<?php echo $btn_id;?>" class="sc-icon color-google">
					<i class="fa fa-google-plus-square"  aria-hidden="true"></i>
				</span>
				<script>
					(function($){
						$('#<?php echo $btn_id;?>').click(function() {
						   	auth2.signIn().then(function() {
							    var user = auth2.currentUser.get();
							    var id_token = user.getAuthResponse().id_token;
							    var data = {
									id_token: id_token,
									action: "verify_reponse"
								};
							    jQuery.ajax({
									type: 'POST',
									dataType: "json",
									url: ae_globals.ajaxURL,
									success: function(result) {
										window.location.href = result.redirect_uri;
									},
									error: function(res){ },
									//processData: false,
									data: data,
								});
							});
						});
				   })(jQuery);
				</script>
			</li>
			<?php
		}
	}

	function add_wp_head_script(){
		if( ! $this->is_enabling() ) { return; } ?>
	    <script src="https://apis.google.com/js/client:platform.js?onload=start" async defer></script>
	    <script>
		    function start() {

		      	gapi.load('auth2', function() {
		        	auth2 = gapi.auth2.init({
		          	client_id: '<?php echo $this->client_id;?>',
		         	redirect_uri:'postmessage',
		          	// Scopes to request in addition to 'profile' and 'email'
		          	//scope: 'additional_scope'
		        });

		      });
		    }

		    function signInCallback(authResult) {
		    	console.log('signInCallback');
		    	console.log(authResult);
				if (authResult['code']) {
					var data = {
						code: authResult['code'],
						action: "verify_reponse"
					};
					jQuery.ajax({
						type: 'POST',
						dataType: "json",
						url: ae_globals.ajaxURL,
						success: function(result) {
							console.log(result);
							// Handle or verify the server response.
						},
						error: function(res){ console.log(res); },
						//processData: false
						data: data,
					});
				} else {
					console.log('empty code');
					// There was an error.
				}
			}
		  </script>
		<?php
	}
}
new Google_Login();
/**
	keep to undestand how wp_remote_ query correct
	*/
	function verify_reponse_old(){

		$code = $_REQUEST['code'];
		$resp = array(
			'success' => true,
			'msg' =>'OK'
		);

		// $this->gplus_exchange_url = 'https://www.googleapis.com/oauth2/v3/token';

		$url = "https://oauth2.googleapis.com/token?code=$code&
		client_id=your_client_id&
		client_secret=your_client_secret&
		redirect_uri=https%3A//oauth2.example.com/code&
		grant_type=authorization_code";

		$redirect_uri = home_url('?action=gplus_auth_callback');
		//https://lab.enginethemes.com/qae/?action=gplus_auth_callback
		//https://lab.enginethemes.com/qae/?action=gplus_auth_callback"
		$redirect_uri = esc_url('https://lab.enginethemes.com/qae/?action=gplus_auth_callback');

		$headers = array(
			'Host'=> 'oauth2.googleapis.com',
			'Content-Type' =>'application/x-www-form-urlencoded',
		);

		$args = array(
			'method' => 'POST',
			'body' => array(
			    'grant_type' => 'authorization_code',//refresh_token, authorization_code
			    'code' => $_REQUEST['code'],
			    //'redirect_uri' =>  $redirect_uri,
			    'redirect_uri' => 'postmessage',
			    'client_id' => GOOGLE_CLIENT_ID,
			    'client_secret' => GOOGLE_SECRET_KEY,
			    'scope' => 'profile https://www.googleapis.com/auth/drive.metadata.readonly',
			),
			'headers' => $headers,
			'httpversion' => '1.1',
			'timeout'     => 120,
		);
		$uri = "https://oauth2.googleapis.com/token";



		$remote_post = wp_remote_post( $uri, $args ); // same same et_google_auth --- auth_google
		//https://developers.google.com/identity/protocols/oauth2/web-server#httprest_3
		$data = json_decode( $remote_post ['body'] );
		$access_token = $data->access_token;
		$uri = "https://www.googleapis.com/drive/v2/files";
		$headers = array(
			'Authorization' => "Bearer ".$access_token,
		);
		$args = array(
			'method' => 'GET',
			'body' => array(
			    'access_token' => $access_token,
			),
			'headers' => $headers,
			'httpversion' => '1.1',
			'timeout'     => 120,
		);
		$remote_get = wp_remote_get( $uri, $args );
		$data = json_decode( $remote_get ['body'] );
		//https://oauth2.googleapis.com/tokeninfo?id_token=XYZ123
		//header('Location: ' . filter_var($redirect_uri, FILTER_SANITIZE_URL));
		wp_send_json($resp);
	}