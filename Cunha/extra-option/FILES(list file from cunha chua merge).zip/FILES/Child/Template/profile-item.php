<?php
/**
 * The template for displaying profile in a loop
 * @since  1.0
 * @package FreelanceEngine
 * @category Template
 */
global $wp_query, $ae_post_factory, $post;
$post_object = $ae_post_factory->get( PROFILE );
$current = $post_object->current_post;
if(!$current){
    return;
}
$hou_rate = (int) $current->hour_rate;
//custom code here

 $last_name_fre=substr(get_user_meta( $post->post_author, 'last_name', true ),0,1).'.';
$first_name_fre=get_user_meta( $post->post_author, 'first_name', true );

$et_options=get_option("et_options");

$hide_freelancer_title=$et_options['hide-freelancer-professional-title'] ? $et_options['hide-freelancer-professional-title'] : 0;
$hide_freelancer_yearexp=$et_options['hide-freelancer-yearexp'] ?  $et_options['hide-freelancer-yearexp'] : 0;
$hide_freelancer_hourRate=$et_options['hide-freelancer-hourRate'] ?  $et_options['hide-freelancer-hourRate'] : 0;
$hide_freelancer_description=$et_options['hide-freelancer-description'] ?  $et_options['hide-freelancer-description'] : 0;


//end
?>
<li class="profile-item">
    <div class="profile-list-wrap">
        <a class="profile-list-avatar" href="<?php echo $current->permalink; ?>">
            <?php echo get_avatar($post->post_author); ?>
        </a>
        <h2 class="profile-list-title">
            <a href="<?php echo $current->permalink; ?>">
            <?php 
            //echo $current->author_name; 
            //custom code here
                echo  $first_name_fre.' '.$last_name_fre;
                //end

                //custom code for validation here
            $args=array('post_type'=>'validation',
                        'post_status'=>'publish',
                        'author'=>$current->post_author,
                                        );
                                    $validated_document=get_posts($args);
                                    if(!empty($validated_document) && get_post_meta($validated_document[0]->ID,'approve_status',true) == 'publish' )
                                    {
                                         echo '<img src="'.get_stylesheet_directory_uri().'/assets/img/verified.png'.'"><em style="font-size:12px;color:#008000;"> Verificado</em>'; 
                                    }    
                                    //end

        ?></a>
        </h2>
        <p class="profile-list-subtitle"><?php if(!$hide_freelancer_title) echo $current->et_professional_title;
            else
                echo 'the professional title is private';
            ?></p>
        <div class="profile-list-info">
            <div class="profile-list-detail">
                <span class="rate-it" data-score="<?php echo $current->rating_score ; ?>"></span>
                <span><?php
                 if(!$hide_freelancer_yearexp)
                 echo $current->experience;
                else
                    echo 'year experience is private';
            ?></span>
                <span><?php echo $current->project_worked; ?></span>

                <?php 
                if(!$hide_freelancer_hourRate)
                {
                     if( $hou_rate > 0 ) 
                        {
                         echo '<span>'; echo $current->hourly_rate_price;
                          echo '</span>'; 
                      }
                }
                 else
                 {
                    echo '<span style="margin-right:15px;"> hour rate is private</span>';
                 }      


                ?>

                <span style="font-weight: normal"><?php echo ($current->earned); ?></span>
            </div>
            <div class="profile-list-desc">
	            <?php if(!$hide_freelancer_description) echo $current->excerpt;
                 else echo '<span>The description is private</span>';
                ?>
            </div>
        </div>
    </div>
</li>
