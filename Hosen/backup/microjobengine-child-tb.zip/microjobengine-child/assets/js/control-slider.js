(function ($) {
  $(document).ready(function () {

  	 $('.my-slider').slick({
		slidesToShow: 2,
  		slidesToScroll: 2,
		speed:300,
		touchThreshold:20,
		cssEase: 'linear',
  	 	mobileFirst:true,  	 
   		infinite: false,
		draggable: true,  	
  		swipe: true,
  		swipeToSlide: true,      
  		prevArrow: false,					
  		nextArrow:'<img style="cursor:pointer;width:30px;height:30px;position:absolute;top:40%;right:5px;" src="https://korosell.com/wp-content/themes/microjobengine-child/img/next-icon-blue.png">',
  responsive: [    
    {
      breakpoint: 991,
      settings: 
      {
         slidesToShow: 4,
         slidesToScroll: 4, 
      	 speed:300,
		touchThreshold:20,
		cssEase: 'linear',
  	 	mobileFirst:true,  	 
   		infinite: false,
		draggable: true,  	
  		swipe: true,
  		swipeToSlide: true,      
  		prevArrow: false,		        
        nextArrow:'<img style="cursor:pointer;width:30p;height:30px;position:absolute;top:45%;right:-50px;" src="https://korosell.com/wp-content/themes/microjobengine-child/img/next-icon-blue.png">',
      },
    },
	
	//ipad
      {
      breakpoint: 600,
      settings: {
        slidesToShow: 2,
        slidesToScroll: 2,
       	speed:300,
		touchThreshold:20,
		cssEase: 'linear',
  	 	mobileFirst:true,  	 
   		infinite: false,
		draggable: true,  	
  		swipe: true,
  		swipeToSlide: true,      
  		prevArrow: false,		
          nextArrow: '<img style="cursor:pointer;width:35px;height:35px;position:absolute;top:40%;right:-3%;" src="https://korosell.com/wp-content/themes/microjobengine-child/img/next-icon-blue.png">',
		
		 
      }
    },

		// mobile
     {
      breakpoint: 400,
      settings: {
        slidesToShow: 2,
        slidesToScroll: 4,
       	speed:300,
		touchThreshold:20,
		cssEase: 'linear',
  	 	mobileFirst:true,  	 
   		infinite: false,
		draggable: true,  	
  		swipe: true,
  		swipeToSlide: true,      
  		prevArrow: false,		 
         nextArrow:'<img style="width:30p;height:30px;position:absolute;top:45%;right:0" src="https://korosell.com/wp-content/themes/microjobengine-child/img/next-icon-blue.png"></div>',		  		
      }
    },

     ],

  });

  });
})(jQuery);