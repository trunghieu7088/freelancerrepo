(function ($) {
  $(document).ready(function () {

    setTimeout(function()
            { 

               $.ajax({
                    type : "get", //Phương thức truyền post hoặc get
                    dataType : "json", //Dạng dữ liệu trả về xml, json, script, or html
                    url : 'https://korosell.com/wp-admin/admin-ajax.php', //Đường dẫn chứa hàm xử lý dữ liệu. Mặc định của WP như vậy
                    data : {
                        action: "get_unread_conversation_for_mjob_page", //Tên action                      
                    },
                    context: this,
                    beforeSend: function(){
                        
                    },
                    success: function(response) {
                        
                        if(response.success) 
                        {                          
                             if(response.data.count > 0 )    
                             {
                                 var order_message_parent = $('#et-header').find('#order-message-icon');
                                 order_message_parent.find('.alert-sign').remove();
                                 order_message_parent.find('#noti-order-message').prepend('<span style="display: block;position: absolute;top: -3px;left: 10px;height: 14px;background: #e52e5d;border-radius: 3px;z-index: 99;font-size: 10px;line-height: 14px;color: #fff;text-align: center;padding: 0 3px;box-sizing: initial;" class="alert-sign">'+ response.data.count+'</span>');
                             }
                             if(response.data.count  == 0)
                             {                               
                                 var order_message_parent = $('#et-header').find('#order-message-icon');
                                 order_message_parent.find('.alert-sign').remove();
                             }
                        }
                      
                    },
                    error: function( jqXHR, textStatus, errorThrown ){                        
                        console.log( 'The following error occured: ' + textStatus, errorThrown );
                    }
                })
                


            }, 500);

  });
})(jQuery);