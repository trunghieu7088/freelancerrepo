(function ($) {
  $(document).ready(function () {
    $(document).on('heartbeat-send', function (event, data) {
      data.conversation_nonce = mje_heartbeat.conversation_nonce;
      data.notification_nonce = mje_heartbeat.notification_nonce;
      data.order_message_nonce = mje_heartbeat.order_message_nonce;
    });

    $(document).on('heartbeat-tick', function (event, data) {
               
      let client_unread_order_message_count=Number($('#et-header').find('#order-message-icon').find('.alert-sign').text());        
  		  let client_noti_count=Number($('#et-header').find('.notification-icon').find('.alert-sign').text());
        var is_single_order_page=Number($('#order_page_check').val());
      
		
		 if(data.unread_notification.notification_count > 0)
      {		   
        var noti_parent = $('#et-header').find('.notification-icon');
        noti_parent.find('.alert-sign').remove();
        noti_parent.find('.link-message').prepend('<span class="alert-sign">'+ data.unread_notification.notification_count+'</span>');
      }
      if(data.unread_notification.notification_count == 0 && client_noti_count != 0)
      {
         var noti_parent = $('#et-header').find('.notification-icon');
        noti_parent.find('.alert-sign').remove();      
		
      }
		
        
      if(data.order_message_count.count > 0  && data.order_message_count.id.includes(is_single_order_page) == false )         
      {
        var order_message_parent = $('#et-header').find('#order-message-icon');
        order_message_parent.find('.alert-sign').remove();
        order_message_parent.find('#noti-order-message').prepend('<span style="display: block;position: absolute;top: -3px;left: 10px;height: 14px;background: #e52e5d;border-radius: 3px;z-index: 99;font-size: 10px;line-height: 14px;color: #fff;text-align: center;padding: 0 3px;box-sizing: initial;" class="alert-sign">'+ data.order_message_count.count+'</span>');
      }
      
      if(data.order_message_count.count == 0 && client_unread_order_message_count != 0)
      {        
        var order_message_parent= $('#et-header').find('#order-message-icon');
         order_message_parent.find('.alert-sign').remove();

      }


      if (typeof data.unread_messages.count === 'undefined') { return; }

       var parent = $('#et-header').find('.message-icon');
      parent.find('.alert-sign').remove();
      parent.find('.link-message').prepend('<span class="alert-sign">'+ data.unread_messages.count +'</span>');
      parent.find('.list-message-box-header .unread-message-count').text();
      parent.find('.list-message-box-body').html(data.unread_messages.dropdown_html);

    });
  });
})(jQuery);