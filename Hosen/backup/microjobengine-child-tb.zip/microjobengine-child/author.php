<?php
/**
 * Template Name: Page Author
 */
global $wp_query, $ae_post_factory, $post, $current_user, $user_ID;

$author_id 	= get_query_var('author');
$author = mJobUser::getInstance();
$author_data = $author->get($author_id);

// Convert profile
$profile_obj = $ae_post_factory->get('mjob_profile');
$profile_id = get_user_meta($author_id, 'user_profile_id', true);
if($profile_id) {
    $post = get_post($profile_id);
    if($post && !is_wp_error($post)) {
        $profile = $profile_obj->convert($post);
    }
}

get_header();
?>
<div id="content">
    <div class="container mjob-profile-page mjob-author-page">
        <div class="title-top-pages">
            <p class="block-title"><?php printf(__('%s\'s profile', 'enginethemes'), $author_data->display_name); ?></p>
        </div>
        <div class="row profile user-public-profile">
            <div class="col-lg-4 col-md-4 col-sm-12 col-sx-12 block-items-detail profile">
                <?php get_sidebar('public-profile'); ?>
            </div>

            <div class="col-lg-8 col-md-8 col-sm-12 col-sx-12" style="padding-right:0px;padding-left:0px;">
                <?php
                global $mjob_is_author;
                $mjob_is_author = true;
                ?>

            
              
                   <div class="information-items-detail box-shadow" style="padding-right:30px;padding-left:30px;">
                        <div class="tabs-information">

                            <ul class="nav nav-tabs" role="tablist">
                                <li role="presentation" class="active"><a href="#order" aria-controls="order" role="tab" data-toggle="tab"><?php _e('ADS', 'enginethemes'); ?></a></li>
                                <li role="presentation"><a href="#task" id="review_trigger" aria-controls="task" role="tab" data-toggle="tab"><?php _e('Reviews', 'enginethemes'); ?></a></li>
                            </ul>
                            <div class="tab-content">
                                <div role="tabpanel" class="tab-pane active order-container-control" id="order">
                                    <div class="filter-order">                                                                               </div>
                                    
                                     <?php
                    $args = array(
                        'post_type' => 'mjob_post',
                        'author' => $author_id,
                        'post_status' => array( 'publish', 'unpause' )
                    );
                    $mjob_posts = new WP_Query( $args );
                    $postdata = array();
                    $post_obj = $ae_post_factory->get( 'mjob_post' );
                    if( $mjob_posts->have_posts() ) :
                    ?>
                     <ul class="mjob-list mjob-list--horizontal">
                    <?php
                        while ( $mjob_posts->have_posts() ) :
                            $mjob_posts->the_post();
                            $convert = $post_obj->convert( $post );
                            $postdata[] = $convert;
                        ?>
                       
                            <?php mje_get_template( 'template/mjob-item.php', array( 'current' => $convert ) ); ?>
                        
                        <?php endwhile; ?>
                        <?php wp_reset_postdata();  ?>
                    </ul>
                    <?php else: ?>
                        <p class="no-items"><?php _e('There are no ADS found!', 'enginethemes'); ?></p>
                    <?php endif; ?>


                      <?php
                        echo '<div class="paginations-wrapper float-center">';
                        ae_pagination($mjob_posts, get_query_var('paged'), 'load');
                        echo '</div>';
                        /**
                         * render post data for js
                         */
                        echo '<script type="data/json" class="mjob_postdata" >' . json_encode($postdata) . '</script>';
                    ?>


                                </div>

                                <div role="tabpanel" class="tab-pane task-container-control" id="task" style="margin-top: 15px !important;">
                                    <div class="filter-order">                                       
                                    </div>
    <div class="mjob-single-page" style="padding-bottom:0px !important;">
 <div class="mjob-single-primary" style="margin-top:0px !important;">
            <div class="row">
                <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">

<div class="mjob-single-content" style="margin-bottom: 0px !important;">
                        <div class="mjob-single-review mjob-single-block" style="padding-bottom:0px !important;">
                                    <div class="review-job">
  
    <ul class="mjob-list mjob-list--horizontal">
        <?php
        $new_array=array();
        $total_reviews=0;
        $all_post_id_of_author=get_posts(array('fields'=>'ids','author'=>$author_id,'numberposts'=>-1,'post_type'=>'mjob_post','post_status' => array( 'publish', 'unpause' )));
      // echo $author_id;
		//echo '<br>';
     //   var_dump($all_post_id_of_author);
        foreach($all_post_id_of_author as $id_of_post)
        {
              $total_args =  array(
            'type' => 'mjob_review',
            'post_id' => $id_of_post ,
            'paginate' => 'load',
            'order' => 'DESC',
            'orderby' => 'date',
            );
                 $query_args = wp_parse_args(array(
                    'number' => $reviews_per_page,
                    'page' => 1
                ), $total_args); 
                 $total_reviews += count(get_comments($total_args));
                   $review_obj = MJE_Review::get_instance();
                    $reviews = $review_obj->fetch($query_args);
                      $new_array[]= $reviews['data'];

        }
        $reviews_per_page = 20;
       /* $total_args =  array(
            'type' => 'mjob_review',
            'post_id' => $mjob_post->ID ,
            'paginate' => 'load',
            'order' => 'DESC',
            'orderby' => 'date',
        );
        
        $query_args = wp_parse_args(array(
            'number' => $reviews_per_page,
            'page' => 1
        ), $total_args); 
        */

        // Get reviews
     //   $review_obj = MJE_Review::get_instance();
       // $reviews = $review_obj->fetch($query_args);
        //$reviews = $reviews['data'];
     //   $new_array[]= $reviews['data'];
        //var_dump($reviews);
        $review_data = array();

        // Get total reviews
      //  $total_reviews = count(get_comments($total_args));
        // Get review pages
        //$review_pages  =   ceil($total_reviews/$query_args['number']);
        $review_pages  =   ceil($total_reviews/$reviews_per_page);
        $query_args['total'] = $review_pages;
      //  var_dump($new_array);
        if(!empty($new_array)):
            foreach($new_array as $item)
            {
            foreach($item as $key => $value) {
                $review_data[] = $value;
                ?>
                <li id="review-<?php echo $value->comment_ID; ?>" class="review-item clearfix">
                    <div class="image-avatar">
                        <?php echo $value->avatar_user; ?>
                    </div>
                    <div class="profile-viewer">
                        <a href="<?php echo $value->author_data->author_url; ?>" class="name-author">
                            <?php echo $value->author_data->display_name; ?>
                        </a>
                        <p class="review-time"><?php echo $value->date_ago; ?></p>
                        <div class="rate-it star" data-score="<?php echo $value->et_rate; ?>"></div>
                        <div class="commnet-content"><?php echo $value->comment_content;  ?></div>
                        <?php
                         $post_of_comment=get_post($value->comment_post_ID);

                        ?>
                        <p><a href="<?php echo site_url('?p='.$post_of_comment->ID); ?>"><?php echo $post_of_comment->post_title ?></a></p>
                    </div>
                </li>
                <?php
            }
        }
        endif; ?>
    </ul>

    <div class="paginations-wrapper" >
        <?php
        if($review_pages > 1) {
            ae_comments_pagination($review_pages, $paged ='' ,$query_args);
        }
        ?>
    </div>
    <?php echo '<script type="json/data" class="review-data" > ' . json_encode($review_data) . '</script>'; ?>
</div>
</div>
</div>

</div>
</div>
</div>
</div>


                                    
                                </div>
                            </div>

                        </div>
                    </div>

            </div>
        </div>
    </div>
</div>
<?php
get_footer();
?>
<script>
(function ($) {
  $(document).ready(function () {

   
        
        var custom_url = new URLSearchParams(window.location.search);        
        var search_params = custom_url.get('section');
        if(search_params=='review') 
        {
            $("#review_trigger").trigger('click');
        }

  });
})(jQuery);
</script>