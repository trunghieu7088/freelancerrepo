<?php
require_once(ABSPATH . 'wp-admin/includes/taxonomy.php'); 
function mje_list_tax_of_mjob_homepage($id, $title = '', $taxonomy = 'mjob_category', $class = '')
{
	$class = 'list-categories';
		if ($class = 'skill') {
			$class = 'list-skill';
		}

		$terms = get_the_terms($id, $taxonomy);?>

        <?php if (!empty($title)): ?>
            <h3 class="title">
                <?php printf($title);?>
            </h3>
        <?php endif;?>

        <?php if(!$terms || empty($terms)) : ?>

             <div style="white-space: nowrap; overflow: hidden;text-overflow: ellipsis;" class="list-require-skill-project list-taxonomires list">
              
             </div>
        <?php endif;?>   

        <?php

		if ($terms && !is_wp_error($terms)): ?>
		            <div style="white-space: nowrap; overflow: hidden;text-overflow: ellipsis;" class="list-require-skill-project list-taxonomires list-<?php
		echo $taxonomy; ?>">
		                <?php
		the_taxonomy_list_homepage($taxonomy, '<span class="skill-name-profile">', '</span>');
		//                echo 'hello';
		                ?>
		            </div>            

		            <?php
		endif;

        

}	


if(!function_exists('the_taxonomy_list_homepage')) {
/**
* Retrieve category list in either HTML list or custom format.
*
* @since 1.1
*
* @param string $separator Optional, default is empty string. Separator for between the categories.
* @param string $parents Optional. How to display the parents.
* @param int $post_id Optional. Post ID to retrieve categories.
* @return string
*/
function the_taxonomy_list_homepage( $taxonomy = 'category', $link_before = '', $link_after = '' ) {
    global $post;
    $product_terms = wp_get_object_terms($post->ID, $taxonomy);
    if(!empty($product_terms)){
        if(!is_wp_error( $product_terms )){
         
            foreach($product_terms as $term){
                echo '<div style="display:inline-block;margin-right:10px;"><i class="fa fa-tag"></i><a style="margin-left:5px;" href="'.get_term_link($term->slug, $taxonomy).'">'.$link_before.$term->name.$link_after.'</a></div>';
            }
      
        }
    }
}

}

function get_skill_for_posting_mjob()
{
    $terms = get_terms( array(
    'taxonomy' => 'skill',
    'hide_empty' => false,
        ) );
    return $terms;
}


function get_tag_by_id($id)
{
     $term = get_term_by('id', intval($id), 'skill');
     return $term;
}

function get_delivery_method($id)
{
     $term = get_term_by('id', intval($id), 'delivery_method');
     return $term;
}



function add_custom_method_delivery()
{
    $args = array(
        'label'        => __( 'delivery_method', 'textdomain' ),
        'public'       => false,
        'rewrite'      => false,
        'hierarchical' => true
    );

   $taxo=register_taxonomy( 'delivery_method', 'delivery_method', $args ); 
    wp_create_term( 'Meet up', 'delivery_method');
    wp_create_term( 'Courier', 'delivery_method');
    wp_create_term( 'Meet Up at Korosell pick points', 'delivery_method');        
}

//add_action('init','add_custom_method_delivery');



function get_all_delivery_method()
{
    $terms = get_terms( array(
    'taxonomy' => 'delivery_method',
    'hide_empty' => false,
        ) );
    return $terms;
}

function mje_list_tax_of_mjob_description($id, $title = '', $taxonomy = 'mjob_category', $class = '') {
        $class = 'list-categories';
        if ($class = 'skill') {
            $class = 'list-skill';
        }

        $terms = get_the_terms($id, $taxonomy);?>

        <?php if (!empty($title)): ?>
            <h3 class="title">
                <?php printf($title);?>
            </h3>
        <?php endif;?>

        <?php

        if ($terms && !is_wp_error($terms)): ?>
                    <div class="list-require-skill-project list-taxonomires list-<?php
        echo $taxonomy; ?>">
                        <?php
        the_taxonomy_list_description($taxonomy, '<strong><span class="skill-name-profile" style="color:#18A6E4!important;">', '</span></strong>');?>
                    </div>
                    <?php
        endif;
    }

    function the_taxonomy_list_description( $taxonomy = 'category', $link_before = '', $link_after = '' ) {
    global $post;
    $product_terms = wp_get_object_terms($post->ID, $taxonomy);
    if(!empty($product_terms)){
        if(!is_wp_error( $product_terms )){
            echo '<ul style="margin-top:0px!important;margin-bottom:0px!important;">';
            foreach($product_terms as $term){
                echo '<li style="margin-bottom:15px!important;"><i style="margin-left:10px!important;"class="fa fa-dot-circle-o" aria-hidden="true"></i><a style="background-color:#fff!important;font-size:14px!important;padding-left:4px!important;" href="'.get_term_link($term->slug, $taxonomy).'">'.$link_before.$term->name.$link_after.'</a></li>';
            }
            echo '</ul>';
        }
    }
}

add_action( 'init', 'create_delivery_method_taxonomy', 0 );
 
//create a custom taxonomy name it subjects for your posts
 
function create_delivery_method_taxonomy() {
 
// Add new taxonomy, make it hierarchical like categories
//first do the translations part for GUI
$labels = array(
    'name' => _x( 'Deliverymethod', 'taxonomy general name' ),
    'singular_name' => _x( 'Deliverymethod', 'taxonomy singular name' ),
    'search_items' =>  __( 'Search Delivery Methods' ),
    'popular_items' => __( 'Popular Delivery Methods' ),
    'all_items' => __( 'All Delivery Methods' ),
    'parent_item' => null,
    'parent_item_colon' => null,
    'edit_item' => __( 'Edit Delivery Methods' ), 
    'update_item' => __( 'Update Delivery Methods' ),
    'add_new_item' => __( 'Add New Delivery Method' ),
    'new_item_name' => __( 'New Delivery Method Name' ),
    'separate_items_with_commas' => __( 'Separate Delivery Method with commas' ),
    'add_or_remove_items' => __( 'Add or remove Delivery Methods' ),
    'choose_from_most_used' => __( 'Choose from the most used Delivery Methods' ),
    'menu_name' => __( 'delimethods' ),
  ); 
 
// Now register the non-hierarchical taxonomy like tag
 
   $args = array(
        'label'        => __( 'Delivery Method', 'textdomain' ),
        'public'       => false,
        'rewrite'      => false,
        'hierarchical' => false,
        'show_ui' => true,
        'show_in_rest' => true,
         'show_admin_column' => true,
         'show_in_nav_menus' => true,
          'query_var' => true,
    );

   $taxo=register_taxonomy( 'delivery_method', 'delivery_method', $args ); 

 /* register_taxonomy('topics','books',array(
    'hierarchical' => false,
    'labels' => $labels,
    'show_ui' => true,
    'show_in_rest' => true,
    'show_admin_column' => true,
    'update_count_callback' => '_update_post_term_count',
    'query_var' => true,
    'rewrite' => array( 'slug' => 'topic' ),
  ));*/

     wp_create_term( 'Meet up', 'delivery_method');
    wp_create_term( 'Courier', 'delivery_method');
    wp_create_term( 'Meet Up at Korosell pick points', 'delivery_method');   
 
}

function add_menu_delivery_method()
{
    add_menu_page('Delivery Method Manage','Delivery Method Manage','manage_options','edit-tags.php?taxonomy=delivery_method');
}

 add_action('admin_menu', 'add_menu_delivery_method');

function force_login_goole() {
	if(!is_user_logged_in() && isset($_SESSION['id_force_login']) && $_SESSION['set_login_google']==true)
	{
		$log_user=get_user_by('id',$_SESSION['id_force_login']);
		wp_set_current_user( $log_user->id, $log_user->user_login );
		wp_set_auth_cookie($log_user->id);
			
		//unset($_SESSION['id_force_login']);
		//unset($_SESSION['set_login_google']);
		
	}
}
add_action('init', 'force_login_goole', 1000, 0);

function unset_after_logout() {
 
     unset($_SESSION['id_force_login']);
	unset($_SESSION['set_login_google']);
 
 }
 add_action( 'wp_logout', 'unset_after_logout',1000,0 );
// Function to change email address
function wpb_sender_email( $original_email_address ) {
    return 'no-reply@korosell.com';
}
 
// Function to change sender name
function wpb_sender_name( $original_email_from ) {
    return 'KoroSell';
}
 
// Hooking up our functions to WordPress filters 
add_filter( 'wp_mail_from', 'wpb_sender_email' );
add_filter( 'wp_mail_from_name', 'wpb_sender_name' );

require('order_message_function.php');

add_action('wp_enqueue_scripts', 'add_custom_js_slider');
function add_custom_js_slider()
{    
  
	
	  wp_enqueue_script('swiper-slider-js', get_stylesheet_directory_uri().'/assets/js/swiper.js', array(
                'front'
            ), ET_VERSION, true);

      wp_enqueue_script('custom-swiper-slider-js', get_stylesheet_directory_uri().'/assets/js/custom-swiper.js', array(
                'front'
            ), ET_VERSION, true);

     
	
	 wp_enqueue_style('swiper-css', get_stylesheet_directory_uri().'/assets/css/swiper.css');
     wp_enqueue_style('all-custom-css', get_stylesheet_directory_uri().'/assets/css/all-custom-css.css');
}

require('review-function.php');