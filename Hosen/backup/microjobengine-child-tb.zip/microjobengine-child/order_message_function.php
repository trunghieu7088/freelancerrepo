<?php
add_action('wp_enqueue_scripts', 'override_heartbeatjs');
function override_heartbeatjs()
{    
    wp_deregister_script('mje-heartbeat');
    wp_enqueue_script('mje-heartbeat', get_stylesheet_directory_uri().'/assets/js/heartbeat.js', array(
                'front'
            ), ET_VERSION, true);
}

add_action('wp_enqueue_scripts', 'add_custom_js_order_message');
function add_custom_js_order_message()
{    
 if (is_single() && 'mjob_order' == get_post_type() )   
    wp_enqueue_script('custom-order-message-js', get_stylesheet_directory_uri().'/assets/js/custom-order-message.js', array(
                'front'
            ), ET_VERSION, true);
}


add_action( 'wp_ajax_get_unread_conversation_for_mjob_page', 'get_unread_conversation_for_mjob_page_init' );

function get_unread_conversation_for_mjob_page_init() {
 
    //do bên js để dạng json nên giá trị trả về dùng phải encode
   // $website = (isset($_POST['website']))?esc_attr($_POST['website']) : '';
    $unread_conversation_update=get_unread_order_conversation();
    wp_send_json_success($unread_conversation_update);
 
    die();//bắt buộc phải có khi kết thúc
}


function add_page_for_order_message()
{
$PageGuid = site_url() . "/order-message-list";
$check_exist=get_page_by_title('Order Message');
      if(empty($check_exist))
      {
        $order_message_page = array( 'post_title'     => 'Order Message',
                         'post_type'      => 'page',
                         'post_name'      => 'order-message-list',
                         'post_content'   => '',
                         'post_status'    => 'publish',
                         'comment_status' => 'closed',
                         'ping_status'    => 'closed',
                         'post_author'    => 1,
                         'menu_order'     => 0,
                         'guid'           => $PageGuid );

      $order_message_page_id=wp_insert_post( $order_message_page, FALSE ); 
      add_post_meta($order_message_page_id,'_wp_page_template','page-order-message-list.php');
      }

}

add_action( 'init', 'add_page_for_order_message' );

function get_unread_order_conversation()
{
    global $post;
    $current_user_id=get_current_user_id();

                     
                        $args = array();
                         $default = array(
                        'post_type' => 'mjob_order',                                             
                        'post_status' => array('finished','disputed','active','disputing','publish','pending'),              
                        'posts_per_page'=>-1,                                                                 
                        'orderby' => 'meta_value',
                        'meta_key' => 'latest_reply_timestamp',                         
                        'order' => 'DESC',   
                        'meta_query' =>array(
                            'relation' => 'AND', 
                            array(
                                    'key'=> 'seller_id',
                                    'value' => $current_user_id,
                                    'compare' => '='
                                    ),
                            'relation' => 'OR', 
                                array(
                                    'key' => 'buyer_id',
                                    'value' => $current_user_id,
                                    'compare' => '='
                                ),
                        ),                                           
                    );     
                          $args = wp_parse_args( $args, $default );
                              $unread_conversation = new WP_Query($args); 
    $unread_conversation_count['count']=0;
    $unread_conversation_count['id']=array();
    while($unread_conversation->have_posts())
    {
          $unread_conversation->the_post();
          
           $latest_reply=get_post_meta($post->ID,'latest_reply',true);
                     
      if(isset($latest_reply) && get_post($latest_reply)) 
      {
        $message = get_post($latest_reply);
               if($current_user_id == get_post_meta( $message->ID,'to_user',true))
               {
                    $is_receiver=true;
                }
                 if($is_receiver==true)
                    {
                         $status=get_post_meta($message->ID,'receiver_unread',true);
                        
                            if($status=='1')
                            {
                                    $unread_conversation_count['count']=$unread_conversation_count['count']+ 1;
                                    $unread_conversation_count['id'][]=$post->ID;
                            }
                            
                   }
      }
    }
    return $unread_conversation_count;
}

//add_action( 'init', 'get_unread_order_conversation' );