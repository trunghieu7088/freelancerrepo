<?php 
/**
 * Template Name: Order Message List
 */
if ( !is_user_logged_in() )
{
    wp_redirect(site_url());
}

global $ae_post_factory, $user_ID;
$post_object = $ae_post_factory->get('ae_message');

get_header();
?>
<div id="content" class="mjob_conversation_list_page">
    <div class="block-page">
        <div class="container dashboard withdraw all-list-message">
            <div class="row title-top-pages">
                <p class="block-title"><?php _e('Order Message List', 'enginethemes'); ?></p>
                <a href="<?php echo et_get_page_link('dashboard'); ?>" class="btn-back"><i class="fa fa-angle-left"></i><?php _e('Back to dashboard', 'enginethemes'); ?></a>
            </div>
            <div class="row">
                <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                    <?php
                    
                    $paged = ( get_query_var( 'paged' ) ) ? get_query_var( 'paged' ) : 1;
                        $post_data = array();
                        $args = array();
                         $default = array(
                        'post_type' => 'mjob_order', 
                        //'author' => $user_ID,                      
                        'post_status' => array('finished','disputed','active','disputing','publish','pending'),              
                        'posts_per_page'=>10,                                                                 
                        'orderby' => 'meta_value',
                        'meta_key' => 'latest_reply_timestamp',                         
                        'order' => 'DESC',                         
                        'paged' =>$paged,
                        'meta_query' =>array(
                            'relation' => 'AND', 
                            array(
                                    'key'=> 'seller_id',
                                    'value' => $user_ID,
                                    'compare' => '='
                                    ),
                            'relation' => 'OR', 
                                array(
                                    'key' => 'buyer_id',
                                    'value' => $user_ID,
                                    'compare' => '='
                                ),
                        ),
                    );                        
                        $args = wp_parse_args( $args, $default );
                        $order_list_query = new WP_Query($args);                        
                       // print_r($order_list_query->request);
                        if($order_list_query->have_posts()) :
                    ?>
                            <ul class="list-conversation">
                                <?php
                                $photo_default=get_template_directory_uri().'/assets/img/mjob.png';
                                if(ae_get_option('default_mjob')){
                                        $default=ae_get_option('default_mjob');
                                        $defautl_thumb=$default['mjob_detail_slider'];
                                        $photo_default=$defautl_thumb[0];
                                }
                                while($order_list_query->have_posts()) :
                                        $order_list_query->the_post();
                                        

                                        $cover_image_link=get_post_meta($post->post_parent,'et_carousels',true);                                        
                                        if(!empty($cover_image_link))
                                        {
                                             foreach($cover_image_link as $key=>$value)
                                            {
                                                $slide = wp_get_attachment_image_src($value, "mjob_detail_slider");
                                                $slide_url = $slide[0];
                                            }                                            
                                        }
                                        else
                                        {
                                            $slide_url= $photo_default;
                                        }
                                                                   
                                         $latest_reply=get_post_meta($post->ID,'latest_reply',true);                                        
                                          if(isset($latest_reply) && get_post($latest_reply)) {
                                               
                                                $message = get_post($latest_reply);
                                             
                                                //If message content null set message content is message title
                                                if($message->post_content == '')
                                                    $message->post_content = $message->post_title;

                                                if($message->post_author == $user_ID) {
                                                    $latest_reply_text = __('You: ', 'enginethemes') . mje_filter_message_content($message->post_content);
                                                } else {
                                                    $latest_reply_text = mje_filter_message_content($message->post_content);
                                                }
                                                $latest_reply_time = et_the_time(get_the_time('U', $message->ID));
                                                if($user_ID == get_post_meta($message->ID,'to_user',true))
                                                {
                                                    $is_receiver=true;
                                                }
                                                if($is_receiver==true)
                                                {
                                                    $status=get_post_meta($message->ID,'receiver_unread',true);
                                                    if($status =='1')
                                                    {
                                                        $unread_class='unread';
                                                    }
                                                    else
                                                    {
                                                        $unread_class='';
                                                    }
                                                }
                                            }
                                            /*
                                             $conversation_status = get_post_meta($post->ID, $user_ID . '_conversation_status', true);

                                                if($conversation_status == "unread") {
                                                    // If unread
                                                    $unread_class = "unread";
                                                } else {
                                                    $unread_class = "";
                                                } */
                                   
                                        echo '<li class="clearfix conversation-item">';
                                            echo '<div class="inner clearfix '.$unread_class.'">';
                                               
                                                echo '<div class="img-avatar">';
                                                    echo '<a href="'.get_the_permalink($post->ID).'">';
                                                        echo '<img style="width:100px;height:100px;" src="'.$slide_url.'">';                                                    
                                                    echo '</a>';
                                                echo '</div>';
                                                
                                                echo '<a href="'.get_the_permalink($post->ID).'">';
                                                    echo '<div class="conversation-text">';
                                                         echo '<p class="name-author">'.$post->post_title.' #'.$post->ID.'</p>';
                                                         echo '<span class="latest-reply">';
                                                              echo isset($latest_reply_text) ? $latest_reply_text : '';
                                                         echo '</span>';
                                                         $time_reply=isset($latest_reply_time) ? $latest_reply_time : '';
                                                        echo ' <p class="latest-reply-time">'.$time_reply.'</p>';
                                                    echo '</div>';
                                                echo '</a>';
                                            
                                            echo '</div>';
                                        echo '</li>';
                                        
                                        

                                    endwhile;
                                    wp_reset_postdata();
                                ?>
                            </ul>
                   
                    <?php else : ?>
                            <p class="not-found"><?php _e('There are no messages found!', 'enginethemes'); ?></p>
                    <?php endif;?>
                    <div class="col-md-12 col-sm-12">
                          <div class="paginations-wrapper text-center">                    
                    <?php
                     if( $order_list_query->have_posts() ) :
                    $big = 999999999;
                    echo '<div style="font-size:14px !important;">';
                                      echo paginate_links( array(
                        'base' => str_replace( $big, '%#%', esc_url( get_pagenum_link( $big ) ) ),
                        'format' => '?paged=%#%',
                        'current' => max( 1, get_query_var('paged') ),
                        'total' => $order_list_query->max_num_pages,
                        'next_text' => '<i class="fa fa-angle-double-right"></i>',
                        'prev_text' => '<i class="fa fa-angle-double-left"></i>',
                        )
                    );
                                      echo '</div>';                  
                     endif;
                ?>
                </div>
            </div>

                </div>
            </div>
        </div>
    </div>



</div>
<?php
    get_footer();
?>
