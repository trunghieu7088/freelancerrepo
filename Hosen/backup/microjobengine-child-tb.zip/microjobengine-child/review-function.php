<?php

if (!function_exists('get_all_comments_of_user_count_custom'))
{	
	function get_all_comments_of_user_count_custom($user_id)
	{
			$posts = get_posts(array(
			'post_type' => 'mjob_post',
			'post_status' => array(
				'publish',
				//'pause',
				'unpause',
			),
			'meta_query' => array(
				array(
					'key' => 'rating_score',
					'value' => 0,
					'compare' => '>',
				),
			),
			'posts_per_page' => -1,
			'author' => $user_id,
		));

		$comment_count = 0;
		foreach ($posts as $post) 
		{
			$args=array('post_id'=>$post->ID,'count'=>true);
			$count = get_comments($args);
			$comment_count += $count;
		}
		
	
		return $comment_count;

	}
}

