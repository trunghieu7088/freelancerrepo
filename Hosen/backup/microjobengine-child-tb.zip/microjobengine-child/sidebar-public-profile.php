<?php
global $wp_query, $ae_post_factory, $post, $current_user, $user_ID;
// If public profile
if(is_author()) {
    $user_id = get_query_var('author');
    $user = mJobUser::getInstance();
    $user_data = $user->get($user_id);
} else {
    $user_id = $current_user->ID;
    $user = mJobUser::getInstance();
    $user_data = $user->convert($current_user->data);
}

// Convert profile
$profile_obj = $ae_post_factory->get('mjob_profile');
$profile_id = get_user_meta($user_id, 'user_profile_id', true);
if($profile_id) {
    $post = get_post($profile_id);
    if($post && !is_wp_error($post)) {
        $profile = $profile_obj->convert($post);
    }
}

// User profile information
$description = !empty($profile->profile_description) ? nl2br($profile->profile_description) : "";
$display_name = isset($user_data->display_name) ? $user_data->display_name : '';
$country_name = isset($profile->tax_input['country'][0]) ? $profile->tax_input['country'][0]->name : '';
$languages = isset($profile->tax_input['language']) ? $profile->tax_input['language'] : '';

// User payment and billing information
$payment_info = !empty($profile->payment_info) ? nl2br($profile->payment_info) : "";
$billing_full_name = !empty($profile->billing_full_name) ? $profile->billing_full_name : "";
$billing_full_address = !empty($profile->billing_full_address) ? nl2br($profile->billing_full_address) : "";
$billing_country = !empty($profile->billing_country) ? $profile->billing_country : '';
$billing_vat = !empty($profile->billing_vat) ? $profile->billing_vat : "";
?>
<div class="personal-profile box-shadow">
    <div class="float-center">
        <?php
        echo mje_avatar($user_id, 75);
        ?>
    </div>
    <h4 class="float-center"><?php echo $display_name; ?></h4>

    <?php if(is_page_template('page-dashboard.php')) : ?>
        <div class="user-email">
            <p><?php echo $user_data->user_email; ?></p>
        </div>
    <?php endif; ?>
    
    <div class="line">
        <span class="line-distance"></span>
    </div>

    <?php // custom here ?>
    <div class="vote text-center" style="margin-top:20px !important;">
		
		 <?php 
                $author_id_custom  = get_query_var('author');
                  if(is_page_template('page-dashboard.php'))
                {
                    $site_custom_url= get_author_posts_url($user_ID).'?section=review';    
                }                
                else
                {   
                     $site_custom_url= get_author_posts_url($author_id_custom).'?section=review'; 
                     
                }

            ?>    
		<a href="<?php echo $site_custom_url; ?>" style="border-bottom: 1px solid #10a2ef;padding-bottom: 3px;">
                    <span style="margin-right:5px;"> 
                    <?php 
                  
                    if(is_page_template('page-dashboard.php'))
                    {
                        echo number_format(mje_get_total_reviews_by_user($user_ID), 1, '.', ' '); 
                    }
                    else
                    {
                        echo number_format(mje_get_total_reviews_by_user($author_id_custom), 1, '.', ' '); 
                    }   

                    ?> 
                    </span>
                    <div class="rate-it star" data-score="<?php if(is_page_template('page-dashboard.php')) echo mje_get_total_reviews_by_user($user_ID); else echo mje_get_total_reviews_by_user($author_id_custom); ?>"></div>
                    <span>( 
                        <?php 
                        if(is_page_template('page-dashboard.php'))  
                            echo get_all_comments_of_user_count_custom($user_ID); 
                        else
                            echo get_all_comments_of_user_count_custom($author_id_custom); 
                    ?> )
                    </span>
			 <i style="font-size:16px;" class="fa fa-angle-double-right" aria-hidden="true"></i>
                </a>
    </div>

    <?php // end custom here ?>



    <ul class="profile">
        <li class="location clearfix">
            <div class="pull-left">
                <span><i class="fa fa-map-marker"></i><?php _e('<span style="color:#0096FF;">Location</span> ', 'enginethemes') ?></span>
            </div>
            <div class="pull-right">
                <?php echo $country_name; ?>
            </div>
        </li>
        <li class="cate-title">
            <div class="pull-left">
                <span><i class="fa fa-phone"></i><?php _e('<span style="color:#0096FF;">Phone</span>', 'enginethemes'); ?></span>
            </div>
            <div class="pull-right">
                <?php echo $billing_vat; ?>
                
            </div>
        </li>

        <?php mJobUser::showUserTimeZone( $user_id ); ?>

        <li class="bio clearfix">
            <span style="color:#0096FF;"> <i class="fa fa-info-circle"></i><?php _e('About', 'enginethemes'); ?></span>
            <?php
                if(is_author()) {
                    $total_words = str_word_count($description);
                    ?>
                    <div class="content-bio <?php echo ($total_words > 50) ? 'hidden-bio gradient' : ''; ?>">
                        <?php
                        echo $description;
                        ?>
                    </div>
                    <?php
                    if($total_words > 50) {
                        echo '<a class="show-bio">'. __('Show more', 'enginethemes') .'</a>';
                    }
                } else {
                    ?>
                    <div class="content-bio">
                        <?php echo wp_trim_words($description, 50, '...'); ?>
                    </div>
                    <?php
                }
            ?>
        </li>
    </ul>

    <?php if(is_page_template('page-dashboard.php')) { ?>
        <div class="edit-profile"><a href="<?php echo et_get_page_link('profile'); ?>"><i class="fa fa-pencil-square-o"></i><?php _e('Edit your profile', 'enginethemes'); ?></a></div>
    <?php } else { ?>
        <div class="link-personal">
            <ul>
                <?php mje_show_contact_link($user_id); ?>
            </ul>
        </div>
    <?php } ?>
</div>