<?php global $user_ID; ?>
<div class="box-shadow box-aside-stat">
    <?php if( is_super_admin() || $user_ID == $mjob_post->post_author ): ?>
        <div class="text-center mjob-status <?php echo $mjob_post->post_status; ?>-text">
            <?php echo $mjob_post->status_text; ?>
        </div>
    <?php endif; ?>

    <div class="mjob-single-stat">
        <div class="stat-block clearfix">
            <div class="vote pull-left">
                <div class="rate-it" data-score="<?php echo round($mjob_post->rating_score, 1); ?>"></div>
                <span class="total-review"><?php printf('(%s)',  $mjob_post->mjob_total_reviews); ?></span>
            </div>
            <span class="price pull-right"><?php echo $mjob_post->et_budget_text; ?></span>
        </div>

        <div class="stat-block">
            <ul>
                <li class="clearfix">
                    <span class="pull-left"><i class="fa fa-star"></i><?php _e('Overall rate', 'enginethemes'); ?></span>
                    <div class="total-number pull-right"><?php echo round($mjob_post->rating_score, 1); ?></div>
                </li>
                <li class="clearfix">
                    <span class="pull-left"><i class="fa fa-commenting"></i><?php _e('Reviews', 'enginethemes'); ?></span>
                    <div class="total-number pull-right"><?php echo mje_get_total_reviews( $mjob_post->ID ); ?></div>
                </li>
                <li class="clearfix">
                    <span class="pull-left"><i class="fa fa-shopping-cart"></i><?php _e('Sales', 'enginethemes'); ?></span>
                    <div class="total-number pull-right"><?php echo mje_get_mjob_order_count($mjob_post->ID); ?></div>
                </li>
                <li class="clearfix">
                    <span class="pull-left"><i class="fa fa-calendar"></i><?php _e('Time of delivery', 'enginethemes'); ?></span>
                    <div class="total-number time-delivery-label pull-right"><?php printf(__('%s day(s)',
                    'enginethemes'),$mjob_post->time_delivery);?></div>
                </li>
            </ul>
        </div>
    </div>
	
    
    <div class="add-extra mjob-add-extra">
        <span class="extra"><?php _e('EXTRA FEE', 'enginethemes') ;?></span>
        <div class="extra-container">
            <?php get_template_part('template/list', 'extras'); ?>
        </div>
    </div>
	
    
</div>

<div class="box-shadow opening-message">
        <div class="aside-title">
            <?php _e('<i style="color:#FF0000" class="fa fa-truck" aria-hidden="true"></i> <strong style="color:#d94a2b;">Delivery Method</strong>', 'enginethemes') ?>
        </div>
        <div class="content">
            <?php       
                $delivery_method=get_post_meta( $mjob_post->ID, 'delivery_method', true);                
                echo '<div class="content-opening-message">';
                echo $delivery_method;
                echo '</div>';                                        
            ?>
        </div>
    </div>
    
    <div class="box-shadow opening-message">
        <div class="aside-title">
            <?php _e('<i style="color:#228B22;" class="fa fa-phone" aria-hidden="true"></i> <strong style="color:#d94a2b;">Contact Number</strong>', 'enginethemes') ?>
        </div>
        <div class="content">
            <?php
            $opening_message = wpautop($mjob_post->opening_message);
            $num_opening_message = str_word_count($opening_message);
            if($num_opening_message > 40) {
                ?>
                <div class="content-opening-message hide-content gradient">
                    <?php
                    echo $opening_message;
                    ?>
                </div>
                <a class="show-opening-message"><?php _e('Show more', 'enginethemes') ?></a>
                <?php
            } else {
                 $phone_num=substr($opening_message,0,6).'xxxxxxx';
                echo '<div class="content-opening-message">';
                echo '<span id="full_num" style="display:none">'.$opening_message.'</span>';
                echo '<span id="short_num">'.$phone_num.'</span>';
                echo '<br>';
                echo '<button onclick="show_full_number()" class="btn btn-primary">';
                echo 'Click here to show full number';
                echo '</button>';
                echo '</div>';
                echo '<a class="show-opening-message"></a>';

            }
            ?>
        </div>
    </div>

    <div class="box-shadow opening-message">
        <div class="aside-title">
            <i class="fa fa-check" data-toggle="collapse" data-target="#safety_tip" style="font-size:16px;color:green;"></i>
            <span data-toggle="collapse" data-target="#safety_tip" style="cursor: pointer;color:#d94a2b;"><strong>Safety Tips</strong></span>
            <span class="caret" data-toggle="collapse" data-target="#safety_tip" style="font-size:20px !important;cursor: pointer;"></span>
        </div>
        <div class="content collapse" id="safety_tip">
        <ul>
            <li>Avoid offers that look unrealistic.</li>
            <li>Chat with the seller to clarify about product details before ordering.</li>
            <li>Only pay over korosell.com website for <a href="https://korosell.com/what-is-korosell-protection/"><strong style="color:#d94a2b;">"K PROTECTION"</strong></a> ADs.</li>
			<li>Meet in a safe & public place if "KoroSell Protection" is not available for this AD.</li>
        </ul> 
			<h4>Click <a href="https://korosell.com/safety-tips/"> here </a>here for more details.</h4>
        </div>
    </div>

<div class="action" style="padding-top:5px !important;border-bottom:none !important;margin-bottom:0px !important;">
	    <?php
        if( $user_ID != $mjob_post->post_author ) {
            $conversation_parent = 0;
            $conversation_guid = '';
            if($conversation = mje_get_conversation( $user_ID, $mjob_post->post_author )) {
                $conversation_parent = $conversation[0]->ID;
                $conversation_guid = $conversation[0]->guid;
            }

            $send_custom_order_id = $class_link_order = 'bt-send-custom';
            if( in_array( $mjob_post->post_status, array( 'pause', 'pending', 'draft', 'reject', 'archive' ) ) ) {
                $send_custom_order_id = 'bt-send-custom-disable';
                $class_link_order= '';
            }
            ?>

		<?php if( $user_ID != $mjob_post->post_author ): ?>
	<?php  if($mjob_post->et_featured ==1):  ?>
		<?php  mje_render_order_button( $mjob_post ); ?>
		 <a style="width:47% !important;cursor:pointer;font-size:14px;padding:20px 10px !important;border-radius:10px !important;background-color:#F10C1D !important;margin-left:5px;" id="<?php echo $send_custom_order_id; ?>" class="btn-submit waves-effect waves-light <?php echo $class_link_order;?>" data-mjob-name="<?php echo $mjob_post->post_title; ?>" data-mjob="<?php echo $mjob_post->ID ?>" data-conversation-guid="<?php echo $conversation_guid; ?>" data-conversation-parent="<?php echo $conversation_parent; ?>" data-to-user="<?php echo $mjob_post->post_author; ?>" data-from-user="<?php echo $user_ID ?>"><?php _e('<strong>Make Offer</strong>','enginethemes'); ?> <i class="fa fa-paper-plane"></i></a>		
		<?php else : ?>
	<strong><button type="button" style="color:#FF0000;">KoroSell Protection is not available for this AD</button></strong>
		<?php endif;  ?>
<?php else : ?>
	<?php do_action('mje_seller_mjob_button'); ?>
<?php endif;  ?>
	


	
	
          
    </div>
<div class="custom-order-link" style="padding:5px !important;">
     
            
                
				   <div>
					     <?php
                  if($mjob_post->et_featured ==1)
                  {
                    ?>
					   <div class="row" style="position:relative;border:1px solid #D3D3D3;border-radius:10px;padding:0px !important;margin:0 !important;">
						   <div class="col-sm-2 col-md-2 col-xs-2" style="padding:15px 5px !important;">
							 <a href="https://korosell.com/what-is-korosell-protection/">  <img src="https://korosell.com/wp-content/uploads/2022/08/korosell-updated-logo-08-07-20222-1.png" style="width:40px;height:40px;"></a>
						   </div>
						    <div class="col-sm-10 col-md-10 col-xs-10 text-left" style="padding:10px 5px !important;">
							 <a style="color:#2a394e !important;" href="https://korosell.com/what-is-korosell-protection/">	 <span><strong>Buy safely with Korosell Protection</strong><br>
									Click "Order Now" to place an order or "Make Offer" to negotiate price. </span>
								<i style="font-size:18px !important;position:absolute;top:5px;right:5px;" class="fa fa-external-link"></i></a>
						   </div>
					   </div>
		    <?php } ?>
		 
	</div>
				
          
            <?php
        }
        ?>
    </div>
<br>

<?php get_sidebar('single-profile'); ?>
<script>
function show_full_number()
{
    document.getElementById("full_num").style.display = "inline";
    document.getElementById("short_num").style.display = "none";
}
</script>