<?php
    global $user_ID;
?>
<div class="clearfix">
    <h3 class="title" style="color:#000!important;size:16px;"><strong><?php _e( 'Product Condition', 'enginethemes' ) ;?></strong></h3>
    <div class="tags text-uppercase" style="margin-bottom:0px!important;color:#18A6E4!important;margin-left:0px;">
       
 <?php mje_list_tax_of_mjob_description( $mjob_post->ID, '', 'skill' ) ?>
    </div>   
</div>

<h3 class="title" style="color:#000!important;size:16px;margin-top:0px!important;"><strong><?php _e( 'Delivery Method', 'enginethemes' ) ;?></strong></h3>
<div class="post-detail description" style="margin-top:10px!important;">
    <div class="blog-content">
        <div class="post-content mjob_post_content text-uppercase" style="color:#18A6E4;margin-left:10px;">
            <strong>
                <i class="fa fa-dot-circle-o" aria-hidden="true"></i>
           <?php       
                $delivery_method=get_post_meta( $mjob_post->ID, 'delivery_method', true);                                
                echo $delivery_method;                     
            ?>
        </strong>
        </div>
    </div>
</div>

<h2 class="title" style="color:#000!important;size:16px;"><strong><?php _e( 'Description', 'enginethemes' ) ;?></strong></h2>
<div class="post-detail description">
    <div class="blog-content">
        <div class="post-content mjob_post_content">
            <?php the_content(); ?>
        </div>
    </div>
</div>
<?php do_action('mjob_post_after_description', $mjob_post);?>
