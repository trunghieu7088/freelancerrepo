<?php
require('realtime-functions.php');
require('smessages.php');
require('send-message-discord-function.php');