<?php
require('realtime-functions.php');
require('smessages.php');