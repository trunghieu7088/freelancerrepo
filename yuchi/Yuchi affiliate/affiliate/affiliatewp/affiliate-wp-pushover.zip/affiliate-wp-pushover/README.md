Pushover Notifications
======================

This add-on for AffiliateWP allows your affiliates to be notified of accepted referrals via Pushover.
