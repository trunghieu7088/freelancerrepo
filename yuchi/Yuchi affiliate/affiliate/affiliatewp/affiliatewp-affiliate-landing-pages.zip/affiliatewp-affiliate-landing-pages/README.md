Affiliate Landing Pages
====================

Create dedicated landing pages for your affiliates, which they can promote without using an affiliate link.

### Version 1.0.3, July 2nd, 2020
* New: Added Polish translation files
* Improved: Added settings to configure custom post type support
* Fixed: User roles Contributor, Author and Editor should not see the post type meta box

### Version 1.0.2, February 1st, 2018
* Fixed: Improved compatibility with AffiliateWP's "Cookie Sharing" option

### Version 1.0.1, March 2nd, 2017
* Fixed: Theme customizer does not load when Affiliate Landing Pages is active

### Version 1.0, February 28th, 2017
* Initial release
