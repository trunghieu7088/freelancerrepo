Custom Affiliate Slugs
====================

Automatically generate custom slugs for your affiliates, or let your affiliates create their own

= Version 1.0, May 3, 2016 =
* Initial release
